http_path = "/"
        css_dir = "../css"
        sass_dir = "."
        images_dir = "../img"
        javascripts_dir = "../js"
        output_style = :nested
        relative_assets=true
        line_comments = false
        