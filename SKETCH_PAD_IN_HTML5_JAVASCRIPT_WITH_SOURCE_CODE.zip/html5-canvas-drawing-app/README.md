html5-canvas-drawing-app
========================

Sketchpad app using html5 canvas to draw using touch or mouse, works on iOS, Android, Window Phone and browser.
App uses touch events, MSPointer events and mouse events to support iOS, Android, Window Phone and desktop browser.
