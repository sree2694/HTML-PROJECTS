HTML5-canvas-projects
=====================

HTML5 Canvas projects - including simple speedometer, shooting game and scroller.